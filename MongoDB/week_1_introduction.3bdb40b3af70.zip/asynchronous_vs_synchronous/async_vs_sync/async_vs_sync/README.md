# Installation
npm install mongodb@1.3.10

# Run mongo shell example
mongo script.js

# Run node.js example
node app.js
